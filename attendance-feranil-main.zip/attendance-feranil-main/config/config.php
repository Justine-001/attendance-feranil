<?php 
	 define('DB_HOST', 'localhost:3306');
	 define('DB_USER', 'root');
	 define('DB_PASS', 'dZWQ4463j!vF');
	 define('DB_NAME', 'rfid_attendance');
?>
	 